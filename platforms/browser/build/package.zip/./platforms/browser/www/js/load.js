function onLoad(){
  document.addEventListener('deviceready', initialize, false);
}
